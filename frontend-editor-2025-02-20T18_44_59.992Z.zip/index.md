 # HTML

 -Hipertext
 -Markup
  -Tags
  -atributos
 -Language

 # CSS

 -Cascating
 -Style
 -Sheet

 # JavaScript

 -Linguagem Interpretada pelo Browser
 -Multiparadigmas

 # Cenário 1

-Cadastrar os usuários da aplicação;
-Gerar link de compartilhamento.

# Cenário 2

-Caso o usuário já tenha cadastro apenas gerar a tela de compartilhamento e mostrar caso alguém já tenha se cadastrado.